"use strict";

document.addEventListener('DOMContentLoaded', () => {

    // Первое задание (изменение цвета ссылок)

    const links=document.querySelectorAll('.link');
    links.forEach(link => {
        link.querySelector('a').style.color="pink";
    });



    // Второе задание ()
    const listbtn = document.querySelector(".list");
    listbtn.addEventListener("click", (e) => {
        const listBlock=document.querySelector('.create-list');

        const list = document.querySelector('.user_list')
       
        listBlock.append(list);
    
        while(true){
            let item=prompt("Что вам нужно?","");
    
            if (!item) break;
    
            let listItem = document.createElement('li');
            listItem.textContent=item;
            list.append(listItem);
        }
    })

   



    // Третье задание (уведомление)

    const notification=document.querySelector('.notif');
    const notifList=['Доброе утро!',];

    function showNotification(text){
        let notif=document.createElement('div');
        notif.className = 'notification';
        notif.textContent=text;
        

        notification.append(notif);

        setTimeout(()=>{notif.remove()},1500);
    }

    setInterval(() => {showNotification('Идет 15-ая учебная неделя!')}, 2500);



    // Четвертое задание ()

    const area=document.querySelector(".area");
    const chicken=area.querySelector('img');

    chicken.style.top=Math.round(area.clientHeight/2 - chicken.offsetHeight/2) + "px";
    chicken.style.left=Math.round(area.clientWidth/2 - chicken.offsetWidth/2) + "px";


    const clickX=document.querySelector('.clickX').querySelector('span');
    const clickY=document.querySelector('.clickY').querySelector('span');

    area.onclick = function(click){
        clickX.textContent=click.clientX;
        clickY.textContent=click.clientY;
    }



    // Пятое задание (кнопка закрытия уведомления)

    const notif = document.querySelector('.notifs');
    const notifBtn = notif.querySelector('.notif__btn');
    const notifInner = notif.querySelector('.notif__inner');
    const notifCounter = notif.querySelector('.notif__counter');
    const notifArr = [
        'Миль Попс',
        'жу-жу-жу-жу-жу-жу',
        'Миль Попс',
        'как же вкусно',
        'ням-ням-ням',
   
    ];
    
    let counter = 0;
    

    function createNotif() {
        let element = document.createElement('div');
        element.classList.add('notif__item');

    
            counter++;
       
            element.textContent = "Уведомление";
      

        element.style=`
        position: relative;
        width: 200px;
        padding: 10px 20px;
        display: inline-block;
        margin-bottom: 2px;
        background:rgb(253, 74, 157);
        border-radius: 10px;
        `;

        notifInner.append(element);

        let closeTab = document.createElement('i');
        closeTab.className = 'fa-solid fa-xmark';

        closeTab.style=`
        position: absolute;
        right: 10px;
        top: 3px;
        cursor: pointer;
        `;

        element.append(closeTab);

        notifCounter.textContent = counter;

        // console.log(notifInner);
    }

    let timerId = setInterval(createNotif, 3000);
    
    notifBtn.addEventListener('click', () => {
        clearInterval(timerId);
        setTimeout(function() {
            timerId = setInterval(createNotif, 3000);
        }, 10000);
    });

    notifInner.onclick = function(event) {
        if (!event.target.classList.contains('fa-xmark')) return; // получаем элемент на котором сработало событие

        let notif = event.target.closest('.notif__item'); // ближайший родственный элемент необходимого класса
        notif.remove();

        counter--;
        notifCounter.textContent=counter;
    };
    

});
