const arr = [10, 15, 1, 5, 8, 11, 13, 20, 45, 32, 25, 7];

function filterArray(arr, a, b) {
    let newArr = [];

    arr.forEach(item => {
        if (item >= a && item <= b) {
            newArr.push(item);
        }
    });

    return newArr;
}

console.log(filterArray(arr, 4, 20));
console.log(filterArray(arr, 13, 40));
console.log(filterArray(arr, 46, 50));
