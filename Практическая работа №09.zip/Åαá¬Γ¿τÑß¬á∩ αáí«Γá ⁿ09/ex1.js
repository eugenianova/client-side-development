login_button.onclick = function (){
    let login = prompt("Введите логин:"); // модальное окно с кнопками ок и отмена
    if(login=='' || login===null){
        alert("Отменено") // сообщение пользователю, ждет когда пользователь нажмет кнопку ок
    }
    else if(login=="Админ"){ // если введен 
        password = prompt("Введите пароль:");
        if(password =='' || password===null){ 
            alert("Отменено")
        }
        else if(password === "Я главный"){
            alert("Здравствуйте!")
        }
        else {
            alert("Неверный пароль");
        }
    }
    else {
        alert("Неизвестный пользователь");
    }
}