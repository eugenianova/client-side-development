reg_btn.onclick = function(){
    var regtext = document.getElementById('registration_input').value;
    if(regtext.toLowerCase()==="да"){
        alert("Круто!");
    }
    else{
        alert("Попробуйте еще раз...");
    }
}
