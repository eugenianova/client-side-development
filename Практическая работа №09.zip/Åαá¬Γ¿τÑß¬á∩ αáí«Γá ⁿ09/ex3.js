const button = document.querySelector(".heart-like-button"); // возвращает первый найденный элемент соотв указанному селектору
var vis = "hidden"; // переменная которая хранит информацию о том, что надо скрыть/показать сердца у курсора

button.addEventListener("click", () => { // addEventListener(type, listener) type - тип события listner - функция
  if (button.classList.contains("liked")) { 
    button.classList.remove("liked"); // добавляем класс элементу
    vis = 'hidden';
  } else {
    button.classList.add("liked");
    vis = 'visible';
  }
});

var hearts_number = 20;

document.addEventListener('mousemove', trail);

var hearts = []; // создаем массив элементов

var Heart = function() {
    var n = document.createElement("div"); // добавляем эти элменты html-файл
    n.className = "mouse_heart";
    document.body.appendChild(n);
    return n;
};

for (let i = 0; i < hearts_number; i++) { // задаем стили
  var h = new Heart();
  h.style.transition = (i+1)*0.015+"s";
  h.style.opacity = (100-(100/hearts_number)*i)+"%";
  hearts.push(h);
}

function trail(e) {
    for (let i = 0; i < hearts_number; i++) {
      hearts[i].style.left = (e.pageX+10) + 'px'; //св-во style - устанавливает стили элемента
      hearts[i].style.top = (e.pageY+10) + 'px'; // положение эелемента 
      hearts[i].style.visibility = vis; // видимость элемента
    }
}


 
