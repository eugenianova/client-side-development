document.addEventListener('DOMContentLoaded', ()=>{

    const btn = document.querySelector(".add");
    var res = document.getElementsByClassName("result")[0];

    function Accumulator(startingValue) {
        this.value = startingValue;
        this.read = function() {
            let v = prompt("Сколько вы хотите добавить элементов?");
            this.value += Number(v);
        };
    }

    btn.addEventListener('click', ()=>{
        console.log("fds");
        var start = Number(res.innerText);
        console.log(start);
        let accumulator = new Accumulator(start);
        accumulator.read();
        res.innerText = accumulator.value;
    });
});