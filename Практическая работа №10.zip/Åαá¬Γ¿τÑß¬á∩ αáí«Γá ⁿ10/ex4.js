 


document.addEventListener('DOMContentLoaded', ()=>{

    const captcha_form=document.querySelector('.captcha');
    const text_btn=document.querySelector('.captcha-text');
    const send_btn=document.querySelector('.captcha-send');
    const input_value=document.querySelector('.captcha-input');
    const alf = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    let word = "";
    for(let i=0;i<8;i++){
        word += alf.charAt(Math.floor(Math.random()*alf.length));
    }

    text_btn.textContent=word;

    let num1 = Math.ceil(Math.random() * 100);
    let num2 = Math.ceil(Math.random() * 100);

    let check=false;

    function isEmpty(obj) {
        for (let i in obj) return false;
        return true;
    }

    send_btn.addEventListener('click',()=>{
        if (isEmpty(input_value.value)) alert("Введите текст");
        else if (word==input_value.value) {
            captcha_form.style.visibility= "hidden";
            captcha_form.style.opacity = 0;
        } 
        else if (!check){
            text_btn.textContent=`${num1} + ${num2} = `;
            check=true;
            input_value.value="";
        }
        else {
            if((num1+num2)==parseInt(input_value.value)) {
                captcha_form.style.opacity = "0%";
                captcha_form.style.visibility="hidden";
            } else {
                alert('Попробуйте еще раз');
                num1 = Math.ceil(Math.random() * 100);
                num2 = Math.ceil(Math.random() * 100);
                text_btn.textContent=`${num1} + ${num2} = `;
                input_value.value=""; // очищаем ввод
            }
        }
    });
});